package com.example.murad.restaurantapps.Activity;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.murad.restaurantapps.R;

public class Parcel_Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_parcel_);
    }
}
