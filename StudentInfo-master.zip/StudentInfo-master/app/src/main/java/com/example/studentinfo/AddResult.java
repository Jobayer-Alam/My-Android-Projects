package com.example.studentinfo;

public class AddResult {
    String name;
    String roll;
    String year;
    String semister;
    String tgpa;

    String courseid1;
    String credit1;
    String gradeno1;

    String courseid2;
    String credit2;
    String gradeno2;

    String courseid3;
    String credit3;
    String gradeno3;

    String courseid4;
    String credit4;
    String gradeno4;

    String courseid5;
    String credit5;
    String gradeno5;

    String courseid6;
    String credit6;
    String gradeno6;

    String courseid7;
    String credit7;
    String gradeno7;

    String courseid8;
    String credit8;
    String gradeno8;

    String courseid9;
    String credit9;
    String gradeno9;

    String courseid10;
    String credit10;
    String gradeno10;

    public AddResult() {

    }

    public AddResult(String tgpa,String name,String roll,String year,String semister) {
        this.tgpa = tgpa;
        this.name = name;
        this.roll = roll;
        this.year = year;
        this.semister = semister;
    }

    public AddResult(String name, String roll, String year, String semister, String courseid1, String credit1, String gradeno1, String courseid2, String credit2, String gradeno2, String courseid3, String credit3, String gradeno3, String courseid4, String credit4, String gradeno4, String courseid5, String credit5, String gradeno5, String courseid6, String credit6, String gradeno6, String courseid7, String credit7, String gradeno7, String courseid8, String credit8, String gradeno8, String courseid9, String credit9, String gradeno9, String courseid10, String credit10, String gradeno10) {
        this.name = name;
        this.roll = roll;
        this.year = year;
        this.semister = semister;
        this.courseid1 = courseid1;
        this.credit1 = credit1;
        this.gradeno1 = gradeno1;
        this.courseid2 = courseid2;
        this.credit2 = credit2;
        this.gradeno2 = gradeno2;
        this.courseid3 = courseid3;
        this.credit3 = credit3;
        this.gradeno3 = gradeno3;
        this.courseid4 = courseid4;
        this.credit4 = credit4;
        this.gradeno4 = gradeno4;
        this.courseid5 = courseid5;
        this.credit5 = credit5;
        this.gradeno5 = gradeno5;
        this.courseid6 = courseid6;
        this.credit6 = credit6;
        this.gradeno6 = gradeno6;
        this.courseid7 = courseid7;
        this.credit7 = credit7;
        this.gradeno7 = gradeno7;
        this.courseid8 = courseid8;
        this.credit8 = credit8;
        this.gradeno8 = gradeno8;
        this.courseid9 = courseid9;
        this.credit9 = credit9;
        this.gradeno9 = gradeno9;
        this.courseid10 = courseid10;
        this.credit10 = credit10;
        this.gradeno10 = gradeno10;

    }

    public String getTgpa() {
        return tgpa;
    }

    public void setTgpa(String tgpa) {
        this.tgpa = tgpa;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getRoll() {
        return roll;
    }

    public void setRoll(String roll) {
        this.roll = roll;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    public String getSemister() {
        return semister;
    }

    public void setSemister(String semister) {
        this.semister = semister;
    }

    public String getCourseid1() {
        return courseid1;
    }

    public void setCourseid1(String courseid1) {
        this.courseid1 = courseid1;
    }

    public String getCredit1() {
        return credit1;
    }

    public void setCredit1(String credit1) {
        this.credit1 = credit1;
    }

    public String getGradeno1() {
        return gradeno1;
    }

    public void setGradeno1(String gradeno1) {
        this.gradeno1 = gradeno1;
    }

    public String getCourseid2() {
        return courseid2;
    }

    public void setCourseid2(String courseid2) {
        this.courseid2 = courseid2;
    }

    public String getCredit2() {
        return credit2;
    }

    public void setCredit2(String credit2) {
        this.credit2 = credit2;
    }

    public String getGradeno2() {
        return gradeno2;
    }

    public void setGradeno2(String gradeno2) {
        this.gradeno2 = gradeno2;
    }

    public String getCourseid3() {
        return courseid3;
    }

    public void setCourseid3(String courseid3) {
        this.courseid3 = courseid3;
    }

    public String getCredit3() {
        return credit3;
    }

    public void setCredit3(String credit3) {
        this.credit3 = credit3;
    }

    public String getGradeno3() {
        return gradeno3;
    }

    public void setGradeno3(String gradeno3) {
        this.gradeno3 = gradeno3;
    }

    public String getCourseid4() {
        return courseid4;
    }

    public void setCourseid4(String courseid4) {
        this.courseid4 = courseid4;
    }

    public String getCredit4() {
        return credit4;
    }

    public void setCredit4(String credit4) {
        this.credit4 = credit4;
    }

    public String getGradeno4() {
        return gradeno4;
    }

    public void setGradeno4(String gradeno4) {
        this.gradeno4 = gradeno4;
    }

    public String getCourseid5() {
        return courseid5;
    }

    public void setCourseid5(String courseid5) {
        this.courseid5 = courseid5;
    }

    public String getCredit5() {
        return credit5;
    }

    public void setCredit5(String credit5) {
        this.credit5 = credit5;
    }

    public String getGradeno5() {
        return gradeno5;
    }

    public void setGradeno5(String gradeno5) {
        this.gradeno5 = gradeno5;
    }

    public String getCourseid6() {
        return courseid6;
    }

    public void setCourseid6(String courseid6) {
        this.courseid6 = courseid6;
    }

    public String getCredit6() {
        return credit6;
    }

    public void setCredit6(String credit6) {
        this.credit6 = credit6;
    }

    public String getGradeno6() {
        return gradeno6;
    }

    public void setGradeno6(String gradeno6) {
        this.gradeno6 = gradeno6;
    }

    public String getCourseid7() {
        return courseid7;
    }

    public void setCourseid7(String courseid7) {
        this.courseid7 = courseid7;
    }

    public String getCredit7() {
        return credit7;
    }

    public void setCredit7(String credit7) {
        this.credit7 = credit7;
    }

    public String getGradeno7() {
        return gradeno7;
    }

    public void setGradeno7(String gradeno7) {
        this.gradeno7 = gradeno7;
    }

    public String getCourseid8() {
        return courseid8;
    }

    public void setCourseid8(String courseid8) {
        this.courseid8 = courseid8;
    }

    public String getCredit8() {
        return credit8;
    }

    public void setCredit8(String credit8) {
        this.credit8 = credit8;
    }

    public String getGradeno8() {
        return gradeno8;
    }

    public void setGradeno8(String gradeno8) {
        this.gradeno8 = gradeno8;
    }

    public String getCourseid9() {
        return courseid9;
    }

    public void setCourseid9(String courseid9) {
        this.courseid9 = courseid9;
    }

    public String getCredit9() {
        return credit9;
    }

    public void setCredit9(String credit9) {
        this.credit9 = credit9;
    }

    public String getGradeno9() {
        return gradeno9;
    }

    public void setGradeno9(String gradeno9) {
        this.gradeno9 = gradeno9;
    }

    public String getCourseid10() {
        return courseid10;
    }

    public void setCourseid10(String courseid10) {
        this.courseid10 = courseid10;
    }

    public String getCredit10() {
        return credit10;
    }

    public void setCredit10(String credit10) {
        this.credit10 = credit10;
    }

    public String getGradeno10() {
        return gradeno10;
    }

    public void setGradeno10(String gradeno10) {
        this.gradeno10 = gradeno10;
    }
}
