package com.example.studentinfo;

public class DatePickerClass {
    String date;

    public DatePickerClass() {
    }

    public DatePickerClass(String date) {
        this.date = date;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
